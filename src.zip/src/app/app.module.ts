import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './Components/login/login.component';
import { GoalComponent } from './Components/dashboard/goal.component';

import { RouterModule } from '@angular/router';
import { AddGoalComponent } from './Components/addgoal/addgoal.component';
import { AddFinancialDataComponent } from './Components/addfiancialdata/addfiancialdata.component';
import { UserProgressComponent } from './Components/user-progress/user-progress.component';

@NgModule({
  declarations: [AppComponent,
     LoginComponent,
      GoalComponent,
      AddGoalComponent,
      AddFinancialDataComponent,
      UserProgressComponent ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
