
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserProgressService {
  private apiUrl = 'http://localhost:5105/api/userprogress'; 

  constructor(private http: HttpClient) {}

  getUserProgress(goalId: number): Observable<any> {
    console.log('Fetching user progress for GoalId:', goalId);
    return this.http.get(`${this.apiUrl}?GoalId=${goalId}`);
  }
}
