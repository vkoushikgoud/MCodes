import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Goal {
  ProfileId: number;
  CurrentAge: number;
  RetirementAge: number;
  TargetSavings: number;
  MonthlyContribution: number;
  CurrentSavings: number;
  GoalId: number;
  TotalSavings: number;
}

@Injectable({
  providedIn: 'root'
})
export class GoalService {
  private apiUrl = 'http://localhost:5105/api/goal'; // Adjust API URL

  constructor(private http: HttpClient) { }

  // GET: Fetch goals by profileId
  getGoals(profileId: number): Observable<Goal[]> {
    return this.http.get<Goal[]>(`${this.apiUrl}/${profileId}`).pipe(
      catchError(this.handleError)
    );
  }

  // POST: Create a new goal
  createGoal(goal: Goal): Observable<any> {
    return this.http.post(this.apiUrl, goal).pipe(
      catchError(this.handleError)
    );
  }

  // Centralized error handler
  private handleError(error: HttpErrorResponse) {
    let errorMsg = 'An unexpected error occurred.';

    if (error.status === 0) {
      errorMsg = 'Unable to connect to the server.';
    } else if (error.status === 404) {
      errorMsg = 'Goal not found.';
    } else if (error.status === 400) {
      errorMsg = 'Invalid request. Please check the data.';
    } else if (error.error instanceof ErrorEvent) {
      errorMsg = `Client error: ${error.error.message}`;
    } else if (typeof error.error === 'string') {
      errorMsg = error.error;
    } else if (error.error?.message) {
      errorMsg = error.error.message;
    }

    console.warn('GoalService Error:', errorMsg); // Friendly log
    return throwError(() => new Error(errorMsg));
  }
}
