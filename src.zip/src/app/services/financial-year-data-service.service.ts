import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface FinancialYearData {
  FId: number;
  GoalId: number;
  Month: number;
  Year: number;
  MonthlyInvestment: number;
  FY: string;
}

@Injectable({
  providedIn: 'root'
})
export class FinancialYearDataService {
  private apiUrl = 'http://localhost:5105/api/financialdata'; 

  constructor(private http: HttpClient) {}

  createFinancialYearData(data: FinancialYearData): Observable<any> {
    return this.http.post(this.apiUrl, data);
  }
  
}
