import { Component } from '@angular/core';
import { LoginService, Login } from '../../services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  userName = '';
  password = '';
  errorMessage = '';

  constructor(private loginService: LoginService, private router: Router) {}

  onLogin(): void {
    const credentials: Login = {
      userName: this.userName,
      password: this.password
    };

    this.loginService.login(credentials).subscribe({
      next: (response) => {
        this.errorMessage = '';
        console.log('Login successful:', response);
        
        // Redirect to goals page with query parameters
        this.router.navigate(['/goals'], {
          queryParams: {
            ProfileId: response.ProfileId,
            UserName: response.UserName,
            Age: response.Age,
            FirstName: response.FirstName,
            LastName: response.LastName
          }
        });
      },
      error: (err) => {
        this.errorMessage = typeof err === 'string' ? err : 'Login failed';
      }
    });
  }
}
