import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddGoalComponent } from './addgoal.component';

describe('AddgoalComponent', () => {
  let component: AddGoalComponent;
  let fixture: ComponentFixture<AddGoalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddGoalComponent]
    });
    fixture = TestBed.createComponent(AddGoalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
