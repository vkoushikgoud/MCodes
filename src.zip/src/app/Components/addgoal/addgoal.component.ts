import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { GoalService, Goal } from '../../services/goal.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-goal',
  templateUrl: './addgoal.component.html',
  styleUrls: ['./addgoal.component.css']
})
export class AddGoalComponent implements OnInit {
  goalForm: FormGroup;
  monthlyContribution: number = 0;
  message = '';
  showSubmitButton = false;

  @Output() closeForm = new EventEmitter<void>();
  @Output() goalAdded = new EventEmitter<Goal>();

  constructor(
    private fb: FormBuilder,
    private goalService: GoalService,
    private activatedRoute: ActivatedRoute
  ) {
    this.goalForm = this.fb.group({
      profileId: [null, Validators.required],
      currentAge: [null, Validators.required],
      retirementAge: [null, [Validators.required, Validators.min(30), Validators.max(100)]],
      targetSavings: [null, [Validators.required, Validators.min(1)]],
      monthlyContribution: [null, Validators.required],
      currentSavings: [null, [Validators.required, Validators.min(0)]],
    }, { validators: this.currentLessThanTarget });
  }

  ngOnInit(): void {
    const profileId = this.activatedRoute.snapshot.queryParams['ProfileId'];
    const Age = Number(this.activatedRoute.snapshot.queryParams['Age']) || 0;

    if (profileId) {
      this.goalForm.patchValue({
        profileId: +profileId,
        currentAge: Age
      });
    }

    // Auto-update monthly contribution when input fields change
    this.goalForm.valueChanges.subscribe(() => {
      this.calculateMonthlyContribution();
    });
  }

  currentLessThanTarget(group: AbstractControl): ValidationErrors | null {
    const current = group.get('currentSavings')?.value;
    const target = group.get('targetSavings')?.value;
    if (current != null && target != null && current >= target) {
      return { savingsTooHigh: true };
    }
    return null;
  }

  calculateMonthlyContribution(): void {
    const { targetSavings, retirementAge, currentAge, currentSavings } = this.goalForm.value;

    const yearsToRetirement = retirementAge - currentAge;
    if (yearsToRetirement > 0 && targetSavings > currentSavings) {
      this.monthlyContribution = (targetSavings - currentSavings) / (yearsToRetirement * 12);
      this.goalForm.patchValue({ monthlyContribution: this.monthlyContribution }, { emitEvent: false });
      this.showSubmitButton = true;
    } else {
      this.goalForm.patchValue({ monthlyContribution: null }, { emitEvent: false });
      this.showSubmitButton = false;
    }
  }

  onSubmit(): void {
    if (this.goalForm.invalid) {
      this.goalForm.markAllAsTouched();
      return;
    }

    const formValue = this.goalForm.value;

    if (formValue.monthlyContribution !== this.monthlyContribution) {
      this.goalForm.get('monthlyContribution')?.setErrors({ mismatch: true });
      return;
    }

    const goal: Goal = formValue;

    this.goalService.createGoal(goal).subscribe({
      next: (response) => {
        this.message = response.message || 'Goal created successfully';
        this.goalAdded.emit(response.Goal);
        this.goalForm.reset();
        this.showSubmitButton = false;
        this.close();
      },
      error: (error) => {
        this.message = error?.message || 'An error occurred';
      }
    });
  }

  close(): void {
    this.closeForm.emit();
  }
}
