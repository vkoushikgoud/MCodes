import {
  Component,
  Input,
  OnInit,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges
} from '@angular/core';
import { UserProgressService } from 'src/app/services/user-progress.service';

@Component({
  selector: 'app-user-progress',
  templateUrl: './user-progress.component.html',
  styleUrls: ['./user-progress.component.css']
})
export class UserProgressComponent implements OnChanges {
  @Input() GoalId!: number;
  @Input() TargetSavings!: number;
  @Output() closePopup = new EventEmitter<void>();

  userProgress: any;
  errorMessage: string = '';
  loading = true;
  percentageSaved: string = '';

  constructor(private userProgressService: UserProgressService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['GoalId'] && this.GoalId) {
      this.loadUserProgress();
    }
  }

  private loadUserProgress(): void {
    this.loading = true;
    this.userProgressService.getUserProgress(this.GoalId).subscribe({
      next: data => {
        this.userProgress = data;

        // Calculate savings percentage with decimals (up to 2 decimal places)
        if (this.TargetSavings && data.TotalSavings != null) {
          const percent = (data.TotalSavings / this.TargetSavings) * 100;
          this.percentageSaved = Math.min(percent, 100).toFixed(2);  // Limit to 2 decimal places
        }

        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load user progress.';
        this.loading = false;
      }
    });
  }

  close(): void {
    this.closePopup.emit();
  }
}
