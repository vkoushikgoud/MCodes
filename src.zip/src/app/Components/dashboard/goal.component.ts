import { Component, OnInit } from '@angular/core';
import { GoalService, Goal } from '../../services/goal.service';
import { Router, ActivatedRoute } from '@angular/router';
import { FinancialYearDataService } from 'src/app/services/financial-year-data-service.service';
import { UserProgressService } from 'src/app/services/user-progress.service';

@Component({
  selector: 'app-goals',
  templateUrl: './goal.component.html',
  styleUrls: ['./goal.component.css']
})
export class GoalComponent implements OnInit {
  goals: Goal[] = [];
  errorMessage: string = '';
  FirstName: string = '';
  LastName: string = '';
  Age: number = 0;
  profileId: number = 0;
  showAddGoalForm = false;
  selectedGoalId: number | null = null;
  selectedTargetSavings: number | null = null;
  selectedGoalTotalSavings: number = 0;
  showAddFinancialDataPopup = false;

  // For User Progress Popup
  showUserProgressPopup = false;
  selectedUserProgressGoalId: number | null = null;

  // For User Details Popup
  showUserDetailsPopup = false;

  constructor(
    private goalService: GoalService,
    private financialYearDataService: FinancialYearDataService,
    private userProgressService: UserProgressService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      this.FirstName = params['FirstName'] || 'Can’t retrieve FirstName';
      this.LastName = params['LastName'] || 'Can’t retrieve LastName';
      this.Age = +params['Age'] || 0;
      this.profileId = +params['ProfileId'] || 0;

      if (this.profileId) {
        this.goalService.getGoals(this.profileId).subscribe({
          next: (data) => {
            this.goals = Array.isArray(data) ? data : [data];

            // Fetch total savings for each goal
            this.goals.forEach(goal => {
              this.userProgressService.getUserProgress(goal.GoalId).subscribe({
                next: (progressData) => {
                  goal.TotalSavings = progressData.TotalSavings;
                },
                error: () => {
                  console.error(`Failed to fetch TotalSavings for goal ${goal.GoalId}`);
                }
              });
            });
          },
          error: (err: any) => {
            this.errorMessage = err.message || 'Failed to load goals.';
          }
        });
      } else {
        this.errorMessage = 'No profile ID found in query parameters.';
      }
    });
  }

  public navigateToLogin(): void {
    this.router.navigate(['/login']);
  }

  // Show User Details Modal
  viewUserDetails() {
    this.showUserDetailsPopup = true;
  }

  // Close User Details Modal
  closeUserDetailsPopup() {
    this.showUserDetailsPopup = false;
  }

  

  onAddFinancialData(goalId: number) {
    this.selectedGoalId = goalId;
    const selectedGoal = this.goals.find(g => g.GoalId === goalId);
  
    if (selectedGoal) {
      const totalSavings = selectedGoal.TotalSavings || 0;
      const targetSavings = selectedGoal.TargetSavings || 0;
      this.selectedGoalTotalSavings = targetSavings - totalSavings;
      
    } else {
      this.selectedGoalTotalSavings = 0;
    }
  
    this.showAddFinancialDataPopup = true;
  }
  onFinancialDataAdded(contribution: number): void {
    if (this.selectedGoalId !== null) {
      const goal = this.goals.find(g => g.GoalId === this.selectedGoalId);
      if (goal) {
        goal.TotalSavings = (goal.TotalSavings || 0) + contribution;
      }
    }
  }
  

  onCloseAddFinancialDataPopup() {
    this.showAddFinancialDataPopup = false;
  }

  addGoal() {
    this.showAddGoalForm = true;
  }

  closeAddGoalForm() {
    this.showAddGoalForm = false;
  }

  onGoalAdded(newGoal: Goal) {
    newGoal.TotalSavings = newGoal.CurrentSavings || 0;
    this.goals = [newGoal, ...this.goals];
    
  }

  openUserProgress(goalId: number, TargetSavings: number) {
    this.selectedUserProgressGoalId = goalId;
    this.selectedTargetSavings = TargetSavings;
    this.showUserProgressPopup = true;
  }

  closeUserProgressPopup() {
    this.showUserProgressPopup = false;
  }

  trackByGoalId(index: number, goal: Goal): number {
    return goal.GoalId;
  }
}
