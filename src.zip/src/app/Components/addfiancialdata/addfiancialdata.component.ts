import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FinancialYearDataService } from '../../services/financial-year-data-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-financial-data',
  templateUrl: './addfiancialdata.component.html',
  styleUrls: ['./addfiancialdata.component.css']
})
export class AddFinancialDataComponent {
  @Input() goalId: number | null = null;
  @Input() totalSavings: number = 0;
  @Output() closePopup = new EventEmitter<void>();
  @Output() financialDataAdded = new EventEmitter<number>(); // <-- NEW

  month: number | null = null;
  year: number | null = null;
  monthlyInvestment: number = 0;
  FY: string = '';
  errorMessage: string = '';
  successMessage: string = '';

  currentYear: number = new Date().getFullYear();

  constructor(
    private financialYearDataService: FinancialYearDataService,
    private router: Router
  ) {}

  onSubmit(): void {
    if (this.isValidForm()) {
      this.addFinancialData();
    }
  }

  isValidForm(): boolean {
    if (!this.month || this.month < 1 || this.month > 12) {
      this.errorMessage = 'Please select a valid month (1-12).';
      return false;
    }

    if (!this.year || this.year < 2021 || this.year > this.currentYear + 10) {
      this.errorMessage = `Please enter a valid year between 2021 and ${this.currentYear + 10}.`;
      return false;
    }

    if (this.monthlyInvestment <= 0) {
      this.errorMessage = 'Monthly Investment must be a positive number.';
      return false;
    }

    if (this.monthlyInvestment > this.totalSavings) {
      this.errorMessage = `Monthly Investment cannot be greater than Total Remaining (${this.totalSavings}).`;
      return false;
    }

    this.errorMessage = '';
    return true;
  }

  addFinancialData(): void {
    if (!this.goalId) {
      this.errorMessage = 'GoalId is missing';
      return;
    }

    const financialData = {
      FId: 0,
      GoalId: this.goalId,
      Month: this.month ?? 1,
      Year: this.year ?? 2021,
      MonthlyInvestment: this.monthlyInvestment,
      FY: this.FY
    };

    this.financialYearDataService.createFinancialYearData(financialData).subscribe({
      next: () => {
        this.successMessage = 'Financial data added successfully!';
        this.financialDataAdded.emit(this.monthlyInvestment); 
        this.closePopup.emit();
      },
      error: (err) => {
        this.errorMessage = 'Error adding financial data: ' + err.message;
        console.error('Error adding financial data', err);
      }
    });
  }

  onClose(): void {
    this.closePopup.emit();
  }
}
